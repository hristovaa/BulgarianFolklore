/*!
 * This file is currently loaded as part of the 'mediawiki' module and therefore
 * concatenated to mediawiki.js and executed at the same time. This file exists
 * to help prepare for splitting up the 'mediawiki' module.
 * This effort is tracked at https://phabricator.wikimedia.org/T192623
 *
 * In short:
 *
 * - mediawiki.js will be reduced to the minimum needed to define mw.loader and
 *   mw.config, and then moved to its own private "mediawiki.loader" module that
 *   can be embedded within the StartupModule response.
 *
 * - mediawiki.base.js and other files in this directory will remain part of the
 *   "mediawiki" module, and will remain a default/implicit dependency for all
 *   regular modules, just like jquery and wikibits already are.
 */
'use strict';

var queue,
	slice = Array.prototype.slice,
	hooks = Object.create( null ),
	mwLoaderTrack = mw.track,
	trackCallbacks = $.Callbacks( 'memory' ),
	trackHandlers = [];

// Apply site-level config
mw.config.set( require( './config.json' ) );

// Load other files in the package
require( './log.js' );
require( './errorLogger.js' );
require( './legacy.wikibits.js' );

/**
 * Object constructor for messages.
 *
 * Similar to the Message class in MediaWiki PHP.
 *
 * Format defaults to 'text'.
 *
 *     @example
 *
 *     var obj, str;
 *     mw.messages.set( {
 *         'hello': 'Hello world',
 *         'hello-user': 'Hello, $1!',
 *         'welcome-user': 'Welcome back to $2, $1! Last visit by $1: $3'
 *     } );
 *
 *     obj = new mw.Message( mw.messages, 'hello' );
 *     mw.log( obj.text() );
 *     // Hello world
 *
 *     obj = new mw.Message( mw.messages, 'hello-user', [ 'John Doe' ] );
 *     mw.log( obj.text() );
 *     // Hello, John Doe!
 *
 *     obj = new mw.Message( mw.messages, 'welcome-user', [ 'John Doe', 'Wikipedia', '2 hours ago' ] );
 *     mw.log( obj.text() );
 *     // Welcome back to Wikipedia, John Doe! Last visit by John Doe: 2 hours ago
 *
 *     // Using mw.message shortcut
 *     obj = mw.message( 'hello-user', 'John Doe' );
 *     mw.log( obj.text() );
 *     // Hello, John Doe!
 *
 *     // Using mw.msg shortcut
 *     str = mw.msg( 'hello-user', 'John Doe' );
 *     mw.log( str );
 *     // Hello, John Doe!
 *
 *     // Different formats
 *     obj = new mw.Message( mw.messages, 'hello-user', [ 'John "Wiki" <3 Doe' ] );
 *
 *     obj.format = 'text';
 *     str = obj.toString();
 *     // Same as:
 *     str = obj.text();
 *
 *     mw.log( str );
 *     // Hello, John "Wiki" <3 Doe!
 *
 *     mw.log( obj.escaped() );
 *     // Hello, John &quot;Wiki&quot; &lt;3 Doe!
 *
 * @class mw.Message
 *
 * @constructor
 * @param {mw.Map} map Message store
 * @param {string} key
 * @param {Array} [parameters]
 */
function Message( map, key, parameters ) {
	this.format = 'text';
	this.map = map;
	this.key = key;
	this.parameters = parameters || [];
	return this;
}

Message.prototype = {
	/**
	 * Get parsed contents of the message.
	 *
	 * The default parser does simple $N replacements and nothing else.
	 * This may be overridden to provide a more complex message parser.
	 * The primary override is in the mediawiki.jqueryMsg module.
	 *
	 * This function will not be called for nonexistent messages.
	 *
	 * @return {string} Parsed message
	 */
	parser: function () {
		var text = this.map.get( this.key );
		if (
			mw.config.get( 'wgUserLanguage' ) === 'qqx' &&
			text === '(' + this.key + ')'
		) {
			text = '(' + this.key + '$*)';
		}
		text = mw.format.apply( null, [ text ].concat( this.parameters ) );
		if ( this.format === 'parse' ) {
			// We don't know how to parse anything, so escape it all
			text = mw.html.escape( text );
		}
		return text;
	},

	/**
	 * Add (does not replace) parameters for `$N` placeholder values.
	 *
	 * @param {Array} parameters
	 * @return {mw.Message}
	 * @chainable
	 */
	params: function ( parameters ) {
		var i;
		for ( i = 0; i < parameters.length; i++ ) {
			this.parameters.push( parameters[ i ] );
		}
		return this;
	},

	/**
	 * Convert message object to its string form based on current format.
	 *
	 * @return {string} Message as a string in the current form, or `<key>` if key
	 *  does not exist.
	 */
	toString: function () {
		if ( !this.exists() ) {
			// Use ⧼key⧽ as text if key does not exist
			// Err on the side of safety, ensure that the output
			// is always html safe in the event the message key is
			// missing, since in that case its highly likely the
			// message key is user-controlled.
			// '⧼' is used instead of '<' to side-step any
			// double-escaping issues.
			// (Keep synchronised with Message::toString() in PHP.)
			return '⧼' + mw.html.escape( this.key ) + '⧽';
		}

		if ( this.format === 'plain' || this.format === 'text' || this.format === 'parse' ) {
			return this.parser();
		}

		// Format: 'escaped'
		return mw.html.escape( this.parser() );
	},

	/**
	 * Change format to 'parse' and convert message to string
	 *
	 * If jqueryMsg is loaded, this parses the message text from wikitext
	 * (where supported) to HTML
	 *
	 * Otherwise, it is equivalent to plain.
	 *
	 * @return {string} String form of parsed message
	 */
	parse: function () {
		this.format = 'parse';
		return this.toString();
	},

	/**
	 * Change format to 'plain' and convert message to string
	 *
	 * This substitutes parameters, but otherwise does not change the
	 * message text.
	 *
	 * @return {string} String form of plain message
	 */
	plain: function () {
		this.format = 'plain';
		return this.toString();
	},

	/**
	 * Change format to 'text' and convert message to string
	 *
	 * If jqueryMsg is loaded, {{-transformation is done where supported
	 * (such as {{plural:}}, {{gender:}}, {{int:}}).
	 *
	 * Otherwise, it is equivalent to plain
	 *
	 * @return {string} String form of text message
	 */
	text: function () {
		this.format = 'text';
		return this.toString();
	},

	/**
	 * Change the format to 'escaped' and convert message to string
	 *
	 * This is equivalent to using the 'text' format (see #text), then
	 * HTML-escaping the output.
	 *
	 * @return {string} String form of html escaped message
	 */
	escaped: function () {
		this.format = 'escaped';
		return this.toString();
	},

	/**
	 * Check if a message exists
	 *
	 * @see mw.Map#exists
	 * @return {boolean}
	 */
	exists: function () {
		return this.map.exists( this.key );
	}
};

/**
 * @class mw
 * @singleton
 */

/**
 * Empty object for third-party libraries, for cases where you don't
 * want to add a new global, or the global is bad and needs containment
 * or wrapping.
 *
 * @property {Object}
 */
mw.libs = {};

// OOUI widgets specific to MediaWiki
mw.widgets = {};

/**
 * @inheritdoc mw.inspect#runReports
 * @method
 */
mw.inspect = function () {
	var args = arguments;
	// Lazy-load
	mw.loader.using( 'mediawiki.inspect', function () {
		mw.inspect.runReports.apply( mw.inspect, args );
	} );
};

/**
 * Replace `$*` with a list of parameters for `uselang=qqx` support.
 *
 * @private
 * @since 1.33
 * @param {string} formatString Format string
 * @param {Array} parameters Values for $N replacements
 * @return {string} Transformed format string
 */
mw.internalDoTransformFormatForQqx = function ( formatString, parameters ) {
	var replacement;
	if ( formatString.indexOf( '$*' ) !== -1 ) {
		replacement = '';
		if ( parameters.length ) {
			replacement = ': ' + parameters.map( function ( _, i ) {
				return '$' + ( i + 1 );
			} ).join( ', ' );
		}
		return formatString.replace( '$*', replacement );
	}
	return formatString;
};

/**
 * Format a string. Replace $1, $2 ... $N with positional arguments.
 *
 * Used by Message#parser().
 *
 * @since 1.25
 * @param {string} formatString Format string
 * @param {...Mixed} parameters Values for $N replacements
 * @return {string} Formatted string
 */
mw.format = function ( formatString ) {
	var parameters = slice.call( arguments, 1 );
	formatString = mw.internalDoTransformFormatForQqx( formatString, parameters );
	return formatString.replace( /\$(\d+)/g, function ( str, match ) {
		var index = parseInt( match, 10 ) - 1;
		return parameters[ index ] !== undefined ? parameters[ index ] : '$' + match;
	} );
};

// Expose Message constructor
mw.Message = Message;

/**
 * Get a message object.
 *
 * Shortcut for `new mw.Message( mw.messages, key, parameters )`.
 *
 * @see mw.Message
 * @param {string} key Key of message to get
 * @param {...Mixed} parameters Values for $N replacements
 * @return {mw.Message}
 */
mw.message = function ( key ) {
	var parameters = slice.call( arguments, 1 );
	return new Message( mw.messages, key, parameters );
};

/**
 * Get a message string using the (default) 'text' format.
 *
 * Shortcut for `mw.message( key, parameters... ).text()`.
 *
 * @see mw.Message
 * @param {string} key Key of message to get
 * @param {...Mixed} parameters Values for $N replacements
 * @return {string}
 */
mw.msg = function () {
	return mw.message.apply( mw, arguments ).toString();
};

/**
 * @see mw.notification#notify
 * @param {HTMLElement|HTMLElement[]|jQuery|mw.Message|string} message
 * @param {Object} [options] See mw.notification#defaults for the defaults.
 * @return {jQuery.Promise}
 */
mw.notify = function ( message, options ) {
	// Lazy load
	return mw.loader.using( 'mediawiki.notification', function () {
		return mw.notification.notify( message, options );
	} );
};

/**
 * Track an analytic event.
 *
 * This method provides a generic means for MediaWiki JavaScript code to capture state
 * information for analysis. Each logged event specifies a string topic name that describes
 * the kind of event that it is. Topic names consist of dot-separated path components,
 * arranged from most general to most specific. Each path component should have a clear and
 * well-defined purpose.
 *
 * Data handlers are registered via `mw.trackSubscribe`, and receive the full set of
 * events that match their subscription, including those that fired before the handler was
 * bound.
 *
 * @param {string} topic Topic name
 * @param {Object|number|string} [data] Data describing the event.
 */
mw.track = function ( topic, data ) {
	mwLoaderTrack( topic, data );
	trackCallbacks.fire( mw.trackQueue );
};

/**
 * Register a handler for subset of analytic events, specified by topic.
 *
 * Handlers will be called once for each tracked event, including any events that fired before the
 * handler was registered; 'this' is set to a plain object with a topic' property naming the event, and a
 * 'data' property which is an object of event-specific data. The event topic and event data are
 * also passed to the callback as the first and second arguments, respectively.
 *
 * @param {string} topic Handle events whose name starts with this string prefix
 * @param {Function} callback Handler to call for each matching tracked event
 * @param {string} callback.topic
 * @param {Object} [callback.data]
 */
mw.trackSubscribe = function ( topic, callback ) {
	var seen = 0;
	function handler( trackQueue ) {
		var event;
		for ( ; seen < trackQueue.length; seen++ ) {
			event = trackQueue[ seen ];
			if ( event.topic.indexOf( topic ) === 0 ) {
				callback.call( event, event.topic, event.data );
			}
		}
	}

	trackHandlers.push( [ handler, callback ] );

	trackCallbacks.add( handler );
};

/**
 * Stop handling events for a particular handler
 *
 * @param {Function} callback
 */
mw.trackUnsubscribe = function ( callback ) {
	trackHandlers = trackHandlers.filter( function ( fns ) {
		if ( fns[ 1 ] === callback ) {
			trackCallbacks.remove( fns[ 0 ] );
			// Ensure the tuple is removed to avoid holding on to closures
			return false;
		}
		return true;
	} );
};

// Fire events from before track() triggered fire()
trackCallbacks.fire( mw.trackQueue );

/**
 * Registry and firing of events.
 *
 * MediaWiki has various interface components that are extended, enhanced
 * or manipulated in some other way by extensions, gadgets and even
 * in core itself.
 *
 * This framework helps streamlining the timing of when these other
 * code paths fire their plugins (instead of using document-ready,
 * which can and should be limited to firing only once).
 *
 * Features like navigating to other wiki pages, previewing an edit
 * and editing itself – without a refresh – can then retrigger these
 * hooks accordingly to ensure everything still works as expected.
 *
 * Example usage:
 *
 *     mw.hook( 'wikipage.content' ).add( fn ).remove( fn );
 *     mw.hook( 'wikipage.content' ).fire( $content );
 *
 * Handlers can be added and fired for arbitrary event names at any time. The same
 * event can be fired multiple times. The last run of an event is memorized
 * (similar to `$(document).ready` and `$.Deferred().done`).
 * This means if an event is fired, and a handler added afterwards, the added
 * function will be fired right away with the last given event data.
 *
 * Like Deferreds and Promises, the mw.hook object is both detachable and chainable.
 * Thus allowing flexible use and optimal maintainability and authority control.
 * You can pass around the `add` and/or `fire` method to another piece of code
 * without it having to know the event name (or `mw.hook` for that matter).
 *
 *     var h = mw.hook( 'bar.ready' );
 *     new mw.Foo( .. ).fetch( { callback: h.fire } );
 *
 * Note: Events are documented with an underscore instead of a dot in the event
 * name due to jsduck not supporting dots in that position.
 *
 * @class mw.hook
 */

/**
 * Create an instance of mw.hook.
 *
 * @method hook
 * @member mw
 * @param {string} name Name of hook.
 * @return {mw.hook}
 */
mw.hook = function ( name ) {
	return hooks[ name ] || ( hooks[ name ] = ( function () {
		var memory, fns = [];
		function rethrow( e ) {
			setTimeout( function () {
				throw e;
			} );
		}
		return {
			/**
			 * Register a hook handler
			 *
			 * @param {...Function} handler Function to bind.
			 * @chainable
			 */
			add: function () {
				var i = 0;
				for ( ; i < arguments.length; i++ ) {
					if ( memory ) {
						try {
							arguments[ i ].apply( null, memory );
						} catch ( e ) {
							rethrow( e );
						}
					}
					fns.push( arguments[ i ] );
				}
				return this;
			},
			/**
			 * Unregister a hook handler
			 *
			 * @param {...Function} handler Function to unbind.
			 * @chainable
			 */
			remove: function () {
				var i = 0, j;
				for ( ; i < arguments.length; i++ ) {
					while ( ( j = fns.indexOf( arguments[ i ] ) ) !== -1 ) {
						fns.splice( j, 1 );
					}
				}
				return this;
			},
			/**
			 * Call hook handlers with data.
			 *
			 * @param {...Mixed} data
			 * @return {mw.hook}
			 * @chainable
			 */
			fire: function () {
				var i = 0;
				for ( ; i < fns.length; i++ ) {
					try {
						fns[ i ].apply( null, arguments );
					} catch ( e ) {
						rethrow( e );
					}
				}
				memory = slice.call( arguments );
				return this;
			}
		};
	}() ) );
};

/**
 * HTML construction helper functions
 *
 *     @example
 *
 *     var Html, output;
 *
 *     Html = mw.html;
 *     output = Html.element( 'div', {}, new Html.Raw(
 *         Html.element( 'img', { src: '<' } )
 *     ) );
 *     mw.log( output ); // <div><img src="&lt;"/></div>
 *
 * @class mw.html
 * @singleton
 */

function escapeCallback( s ) {
	switch ( s ) {
		case '\'':
			return '&#039;';
		case '"':
			return '&quot;';
		case '<':
			return '&lt;';
		case '>':
			return '&gt;';
		case '&':
			return '&amp;';
	}
}
mw.html = {
	/**
	 * Escape a string for HTML.
	 *
	 * Converts special characters to HTML entities.
	 *
	 *     mw.html.escape( '< > \' & "' );
	 *     // Returns &lt; &gt; &#039; &amp; &quot;
	 *
	 * @param {string} s The string to escape
	 * @return {string} HTML
	 */
	escape: function ( s ) {
		return s.replace( /['"<>&]/g, escapeCallback );
	},

	/**
	 * Create an HTML element string, with safe escaping.
	 *
	 * @param {string} name The tag name.
	 * @param {Object} [attrs] An object with members mapping element names to values
	 * @param {string|mw.html.Raw|null} [contents=null] The contents of the element.
	 *
	 *  - string: Text to be escaped.
	 *  - null: The element is treated as void with short closing form, e.g. `<br/>`.
	 *  - this.Raw: The raw value is directly included.
	 * @return {string} HTML
	 */
	element: function ( name, attrs, contents ) {
		var v, attrName, s = '<' + name;

		if ( attrs ) {
			for ( attrName in attrs ) {
				v = attrs[ attrName ];
				// Convert name=true, to name=name
				if ( v === true ) {
					v = attrName;
					// Skip name=false
				} else if ( v === false ) {
					continue;
				}
				s += ' ' + attrName + '="' + this.escape( String( v ) ) + '"';
			}
		}
		if ( contents === undefined || contents === null ) {
			// Self close tag
			s += '/>';
			return s;
		}
		// Regular open tag
		s += '>';
		if ( typeof contents === 'string' ) {
			// Escaped
			s += this.escape( contents );
		} else if ( typeof contents === 'number' || typeof contents === 'boolean' ) {
			// Convert to string
			s += String( contents );
		} else if ( contents instanceof this.Raw ) {
			// Raw HTML inclusion
			s += contents.value;
		} else {
			throw new Error( 'Invalid content type' );
		}
		s += '</' + name + '>';
		return s;
	},

	/**
	 * Wrapper object for raw HTML passed to mw.html.element().
	 *
	 * @class mw.html.Raw
	 * @constructor
	 * @param {string} value
	 */
	Raw: function ( value ) {
		this.value = value;
	}
};

/**
 * Execute a function after one or more modules are ready.
 *
 * Use this method if you need to dynamically control which modules are loaded
 * and/or when they loaded (instead of declaring them as dependencies directly
 * on your module.)
 *
 * This uses the same loader as for regular module dependencies. This means
 * ResourceLoader will not re-download or re-execute a module for the second
 * time if something else already needed it. And the same browser HTTP cache,
 * and localStorage are checked before considering to fetch from the network.
 * And any on-going requests from other dependencies or using() calls are also
 * automatically re-used.
 *
 * Example of inline dependency on OOjs:
 *
 *     mw.loader.using( 'oojs', function () {
 *         OO.compare( [ 1 ], [ 1 ] );
 *     } );
 *
 * Example of inline dependency obtained via `require()`:
 *
 *     mw.loader.using( [ 'mediawiki.util' ], function ( require ) {
 *         var util = require( 'mediawiki.util' );
 *     } );
 *
 * Since MediaWiki 1.23 this returns a promise.
 *
 * Since MediaWiki 1.28 the promise is resolved with a `require` function.
 *
 * @member mw.loader
 * @param {string|Array} dependencies Module name or array of modules names the
 *  callback depends on to be ready before executing
 * @param {Function} [ready] Callback to execute when all dependencies are ready
 * @param {Function} [error] Callback to execute if one or more dependencies failed
 * @return {jQuery.Promise} With a `require` function
 */
mw.loader.using = function ( dependencies, ready, error ) {
	var deferred = $.Deferred();

	// Allow calling with a single dependency as a string
	if ( !Array.isArray( dependencies ) ) {
		dependencies = [ dependencies ];
	}

	if ( ready ) {
		deferred.done( ready );
	}
	if ( error ) {
		deferred.fail( error );
	}

	try {
		// Resolve entire dependency map
		dependencies = mw.loader.resolve( dependencies );
	} catch ( e ) {
		return deferred.reject( e ).promise();
	}

	mw.loader.enqueue(
		dependencies,
		function () { deferred.resolve( mw.loader.require ); },
		deferred.reject
	);

	return deferred.promise();
};

/**
 * Load a script by URL.
 *
 * Example:
 *
 *     mw.loader.getScript(
 *         'https://example.org/x-1.0.0.js'
 *     )
 *         .then( function () {
 *             // Script succeeded. You can use X now.
 *         }, function ( e ) {
 *             // Script failed. X is not avaiable
 *             mw.log.error( e.message ); // => "Failed to load script"
 *         } );
 *     } );
 *
 * @member mw.loader
 * @param {string} url Script URL
 * @return {jQuery.Promise} Resolved when the script is loaded
 */
mw.loader.getScript = function ( url ) {
	return $.ajax( url, { dataType: 'script', cache: true } )
		.catch( function () {
			throw new Error( 'Failed to load script' );
		} );
};

// Skeleton user object, extended by the 'mediawiki.user' module.
/**
 * @class mw.user
 * @singleton
 */
mw.user = {
	/**
	 * @property {mw.Map}
	 */
	options: new mw.Map(),
	/**
	 * @property {mw.Map}
	 */
	tokens: new mw.Map()
};

// Process callbacks for modern browsers (Grade A) that require modules.
queue = window.RLQ;
// Replace temporary RLQ implementation from startup.js with the
// final implementation that also processes callbacks that can
// require modules. It must also support late arrivals of
// plain callbacks. (T208093)
window.RLQ = {
	push: function ( entry ) {
		if ( typeof entry === 'function' ) {
			entry();
		} else {
			mw.loader.using( entry[ 0 ], entry[ 1 ] );
		}
	}
};
while ( queue[ 0 ] ) {
	window.RLQ.push( queue.shift() );
}
