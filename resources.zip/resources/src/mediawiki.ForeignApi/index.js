mw.ForeignApi = require( './mediawiki.ForeignApi.core.js' );
mw.ForeignRest = require( './mediawiki.ForeignRest.core.js' );
