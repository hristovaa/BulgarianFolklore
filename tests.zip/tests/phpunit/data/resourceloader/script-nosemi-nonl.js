/* eslint-disable */
mw.foo()