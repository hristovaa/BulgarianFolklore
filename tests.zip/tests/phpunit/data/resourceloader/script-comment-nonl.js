/* eslint-disable */
mw.foo()
// mw.bar();