<?php

class TestAutoloadedClass {
}
