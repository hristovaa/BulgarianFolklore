<?php
/**
 * This the test fixture for a message file in the English language (en).
 */

// Minimum required variables that must exist in at least the
// fallback language (en), as they are unconditionally accessed
// and assumed to be arrays.
$namespaceNames = [];
$specialPageAliases = [];
$preloadedMessages = [];
