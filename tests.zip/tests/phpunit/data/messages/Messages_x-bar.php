<?php
/**
 * This the test fixture for a message file in the Example Bar language (x-bar).
 */

$namespaceAliases = [
	'Cat' => NS_FILE,
	'Cat_toots' => NS_FILE_TALK,
];

$fallback = 'x-foo';
