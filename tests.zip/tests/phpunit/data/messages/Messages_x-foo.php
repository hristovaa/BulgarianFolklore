<?php
/**
 * This the test fixture for a message file in the Example Foo language (x-foo).
 */

$namespaceAliases = [
	'Cat' => NS_USER,
	'Cat_toots' => NS_USER_TALK,
	'Dog' => NS_USER,
	'Dog' => NS_USER_TALK,
];
