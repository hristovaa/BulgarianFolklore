<?php

/**
 * @group large
 * @covers CurlHttpRequest
 */
class CurlHttpRequestTest extends MWHttpRequestTestCase {
	protected static $httpEngine = 'curl';
}
