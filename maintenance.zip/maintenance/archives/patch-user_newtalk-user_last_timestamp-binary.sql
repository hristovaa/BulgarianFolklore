ALTER TABLE /*_*/user_newtalk
  MODIFY user_last_timestamp BINARY(14);