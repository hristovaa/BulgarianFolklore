ALTER TABLE /*_*/interwiki DROP KEY /*i*/iw_prefix, ADD PRIMARY KEY (iw_prefix);
