ALTER TABLE /*_*/protected_titles MODIFY pt_title VARBINARY(255) NOT NULL;
