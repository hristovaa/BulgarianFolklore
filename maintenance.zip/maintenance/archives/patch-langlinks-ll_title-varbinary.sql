ALTER TABLE /*_*/langlinks MODIFY ll_title VARBINARY(255) NOT NULL default '';
