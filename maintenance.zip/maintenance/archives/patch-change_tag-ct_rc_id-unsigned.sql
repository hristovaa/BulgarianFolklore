ALTER TABLE /*_*/change_tag MODIFY ct_rc_id int unsigned NULL;
