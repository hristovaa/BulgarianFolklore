ALTER TABLE /*_*/image
  ALTER COLUMN img_description SET DEFAULT '';
