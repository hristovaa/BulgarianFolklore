ALTER TABLE /*_*/pagelinks MODIFY pl_title VARBINARY(255) NOT NULL default '';
