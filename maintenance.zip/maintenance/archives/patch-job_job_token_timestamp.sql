ALTER TABLE /*_*/job
  MODIFY job_token_timestamp BINARY(14);