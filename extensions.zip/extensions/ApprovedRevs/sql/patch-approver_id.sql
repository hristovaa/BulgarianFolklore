ALTER TABLE /*_*/approved_revs
  ADD COLUMN approver_id int NOT NULL default 0;
